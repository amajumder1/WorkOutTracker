"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var shared_service_1 = require("./../shared.service");
var CategoryComponent = (function () {
    function CategoryComponent(_sharedService) {
        this._sharedService = _sharedService;
        this.addWorkoutCbpm = 0;
        this.addWorkoutTitle = "";
        this.addWorkoutNote = "";
        this.addWorkoutCategory = "";
    }
    CategoryComponent.prototype.ngOnInit = function () {
        this._sharedService.GetCategory();
    };
    CategoryComponent.prototype.editCategoryFunc = function () {
        this._sharedService.EditCategory(this);
    };
    CategoryComponent.prototype.deleteCategoryFunc = function () {
        this._sharedService.DeleteCategory(this);
    };
    return CategoryComponent;
}());
CategoryComponent = __decorate([
    core_1.Component({
        selector: 'app-category',
        templateUrl: './Category.component.html',
        styles: [],
        providers: [shared_service_1.SharedService]
    }),
    __metadata("design:paramtypes", [shared_service_1.SharedService])
], CategoryComponent);
exports.CategoryComponent = CategoryComponent;
//# sourceMappingURL=Category.component.js.map